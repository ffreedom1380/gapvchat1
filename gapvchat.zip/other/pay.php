<?php

//die("<center><b>پرداخت فعلا غیر فعال است، ربات در دست بروزرسانی ست.</b></center>");

$MerchantID = 'e86ff575-b6bb-4061-8295-f98114f881f3';
$Description = 'ویژه کردن ربات چت ناشناس';
$Email = $from_id;
$Mobile = '09....';
$CallbackURL = $_GET['callback'];
$Amount = $_GET['amount']; 

$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);

$result = $client->PaymentRequest(
[
'MerchantID' => $MerchantID,
'Amount' => $Amount,
'Description' => $Description,
'Email' => $Email,
'Mobile' => $Mobile,
'CallbackURL' => $CallbackURL,
]
);

if ($result->Status == 100) {
Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority);
} else {
echo'ERR: '.$result->Status;
}
?>