<?php
error_reporting(0);
ini_set('display_errors', 0);
include("../index.php");
$MerchantID = ''; // MechantID
$Amount = 20;
$Authority = $_GET['Authority'];
$user = $_GET['id'];
if ($_GET['Status'] == 'OK'){
echo '📍 پرداخت شما موفقیت امیز بود حساب شما ویژه شد';
jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"پرداخت شما موفیت امیز بود ✅",
   	'reply_markup'=>json_encode([
  	'inline_keyboard'=>[
				   [
['text'=>"🔙 برگشت",'callback_data'=>'panel']
				   ]
				   ],
	  	'resize_keyboard'=>true,
  	])
  	]);
sendMessage("$Dev[0]","📍 یک خرید انجام شد
📌 توسط : [$user](tg://user?id=$user)","MarkDown");
file_put_contents("../data/$user.txt","true");
}
else {
echo 'پرداخت انجام نشد';
}
?>